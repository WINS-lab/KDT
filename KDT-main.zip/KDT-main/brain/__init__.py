# coding: utf-8
from brain.knowgraph import KnowledgeGraph
